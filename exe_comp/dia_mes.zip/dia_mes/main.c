#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
    setlocale(LC_CTYPE, "");
    int mes, ano;
    printf("Insira o n�mero referente ao m�s: ");
    scanf("%d", &mes);
    if (mes == 4 || mes ==6 || mes ==9 || mes ==11)
        printf("O m�s tem 30 dias.");
    else if (mes == 2)
    {
        printf("Informe o ano: ");
        scanf("%d", &ano);
        if (ano%400==0 || (ano%4==0 && ano%100!=0))
            printf("O m�s tem 29 dias.");
        else
            printf("O m�s tem 28 dias.");
    }
    else
        printf("O m�s tem 31 dias.");

    return 0;
}
