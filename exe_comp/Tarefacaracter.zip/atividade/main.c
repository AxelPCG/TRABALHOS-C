#include <stdio.h>
#include <string.h>

int main()
{
    char nome[40],prenome[20];
    int l;
    printf("Informe o seu nome completo: ");
    gets(nome);
    l = strcspn(nome," ");
    strncpy(prenome,nome,l);
    prenome[l]='\0';
    printf("Bem vindo %s!",prenome);
    return 0;
}
