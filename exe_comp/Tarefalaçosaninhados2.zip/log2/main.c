#include <stdio.h>
#include <math.h>

int main()
{
    int num,i;
    while(1)
    {
        printf("Entre com o numero que seja potencia de 2: ");
        scanf("%d",&num);
        if(floor(log10(num)/log10(2))==ceil(log10(num)/log10(2)))
            break;
        fflush(stdin);
        printf("Numero errado, tente novamente.\n");
    }

    for(i=1;i<=num;i=i*2)
        printf("%d ",i);
    return 0;
}
