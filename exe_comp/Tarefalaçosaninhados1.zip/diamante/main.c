#include <stdio.h>
#include <stdlib.h>
#define MAX 9 // ALTURA DO DIAMANTE
#define ESP ((MAX-1)/2) // N�MERO INICIAL DE ESPA�OS � DIREITA

int main()
{
    char i=1, j=1,k;
    for(i=1; i <= MAX;i++)
    {
        k = abs(ESP-i+1); // k espa�os, figura � sim�trica em rela��o a i
        for(j=1; j <= MAX - k; j++)
        {
            if(j > k)
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
    return 0;
}
