#include <stdio.h>
#include <stdlib.h>

int main()
{
    for(int i=150;i>=1;i/=3)
        printf("%d ",i);
    return 0;
}
